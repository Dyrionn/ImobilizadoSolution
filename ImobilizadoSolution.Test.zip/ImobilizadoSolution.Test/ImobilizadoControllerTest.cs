﻿
using ImobilizadoSolution.Domain;
using ImobilizadoSolution.Service.Contract;
using ImobilizadoSolution.Web.Models.DTO;
using Moq;
using Xunit;


namespace ImobilizadoSolution.Test
{
    public class ImobilizadoControllerTest
    {

        [Fact]
        public void Adicionar_ImobilizadoAdicionado_Sucesso()
        {
            //arrange
            var servico = new Mock<IImobilizadoService>();
            var imobilizado = new ImobilizadoDTO();
            servico
                .Setup(x => x.Adicionar(It.IsAny<Imobilizado>()))
                .Returns(true);

            //act
            Web.Controllers.ImobilizadoController classeTeste = new Web.Controllers.ImobilizadoController();
            var result = classeTeste.Adicionar(imobilizado);

            //result.
            Assert.True(result.IsSuccessStatusCode);
        }

        [Fact]
        public void Deletar_UsuarioDeletado_Sucesso()
        {
            //arrange
            //var baseDados = new 
            //act

            //assert

        }

    }
}
